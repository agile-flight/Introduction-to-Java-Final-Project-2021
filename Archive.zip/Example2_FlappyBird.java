import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent; 
//import java.awt.event.KeyEvent.*;
class Draw {
    Graphics g;
    Draw(Graphics g) {
        this.g = g;
    };
}
public class Example2_FlappyBird {

    JFrame frame;
    DrawPanel drawPanel;

    public static void main(String... args) {
        new Example2_FlappyBird().go();
    }

    private void go() {
        frame = new JFrame("Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(515, 539));
        frame.setBackground(Color.BLACK);
        frame.pack();
        drawPanel = new DrawPanel();

        frame.getContentPane().add(BorderLayout.CENTER, drawPanel);

        frame.setResizable(true);
        frame.setLocationByPlatform(true);

        frame.setVisible(true);
        
    }
    
    //Global Variables go here
    //Jump Stuff
    public int y = 400;
    public double speedY = 0;
    public double jumpForce = -4;
    public double gravityForce = .2;
    
    
    //x stuff
    public int x = 20;
    public int speedX = 1;
    
    public boolean UpButton = false;
    public boolean DownButton = false;
    public boolean RightButton = false;
    public boolean LeftButton = false;
    public boolean SpaceButton = false;
    public boolean oldSpaceButton = false;
    public boolean JButton = false;
    
    //platforms
    
    int[][] platforms = {{0,410,500,90},
                         {200,300,100,5},
                         {100,200,50,5}};
    
    

    class DrawPanel extends JPanel {
        private static final long serialVersionUID = 1L;     

        public DrawPanel() {
            KeyListener listener = new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {
                }

                @Override
                public void keyPressed(KeyEvent e) {
                    //System.out.println("keyPressed=" + KeyEvent.getKeyText(e.getKeyCode()));
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W ) {
                        UpButton = true;
                        DownButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        UpButton = false;
                        DownButton = true;
                    }
                    if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
                        RightButton = true;
                        LeftButton = false;
                    } else if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
                        RightButton = false;
                        LeftButton = true;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = true;
                    }
                    if (key == KeyEvent.VK_J) {
                        JButton = true;
                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
                        UpButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        DownButton = false;
                    }
                    if (key == KeyEvent.VK_RIGHT|| key == KeyEvent.VK_D) {
                        RightButton = false;
                    } else if (key == KeyEvent.VK_LEFT|| key == KeyEvent.VK_A) {
                        LeftButton = false;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = false;
                    }
                    if (key == KeyEvent.VK_J) {
                        JButton = false;
                    }
                }
            };
            addKeyListener(listener);
            setFocusable(true);
        }

        public void paintComponent(Graphics g) {
            //This code redraw the scene.  Don't change this
            try {
                Thread.sleep(10);
            } catch (Exception e) {
                e.printStackTrace();
            }
            frame.repaint();
            
            //x change
            if (RightButton && x <= 480) 
            {
                x += speedX;
            } 
            else if (LeftButton && x > 0) 
            {
                x -= speedX;
            }
            //y change with jump
            if(y>400)
            {
                y=400;
                speedY = 0;
            }else
            {
                speedY += gravityForce;
            }
            
            y += (int)speedY;
            //Changes the color of the square.
            if(SpaceButton && !oldSpaceButton)
            {
                
                speedY = jumpForce;
            }
            oldSpaceButton = SpaceButton;
            
            //drawing the player
            g.setColor(Color.CYAN);
            g.fillOval(x-10, y-10, 20, 20);
            
            //platforms(they don't do anything.  Just decoration)
            g.setColor(Color.DARK_GRAY);
            for(int p = 0;p<platforms.length;p++)
            {
                g.fillRect( platforms[p][0],platforms[p][1],
                            platforms[p][2],platforms[p][3]);
            }
            
            //This section displays indicators to show when buttons are pushed
            g.setColor(Color.GRAY);
            g.fillRect(40,420,20,20);
            g.fillRect(40,460,20,20);
            g.fillRect(20,440,20,20);
            g.fillRect(60,440,20,20);
            g.fillRect(20,485,60,10);
            g.fillRect(100,485,60,10);
            g.setColor(Color.YELLOW);
            if(UpButton)
                g.fillRect(40,420,20,20);
            if(DownButton)
                g.fillRect(40,460,20,20);
            if(LeftButton)
                g.fillRect(20,440,20,20);
            if(RightButton)
                g.fillRect(60,440,20,20);
            if(SpaceButton)
                g.fillRect(20,485,60,10);
            if(JButton)
                g.fillRect(100,485,60,10);
            String display1 = "DIRECTIONS:";
            String display2 = "up,down,left,and right = move square";
            String display3 = "space bar = jump";
            g.drawString(display1,250 , 450);
            g.drawString(display2,250 , 470);
            g.drawString(display3,250 , 490);
            
            
        }
    }

    
    
}
