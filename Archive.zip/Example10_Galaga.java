import java.awt.*;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent; 
//import java.awt.event.KeyEvent.*;
class Draw {
    Graphics g;
    Draw(Graphics g) {
        this.g = g;
    };
}
public class Example10_Galaga {

    JFrame frame;
    DrawPanel drawPanel;

    public static void main(String... args) {
        new Example10_Galaga().go();
    }

    private void go() {
        frame = new JFrame("Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(515, 539));
        frame.setBackground(Color.BLACK);
        frame.pack();
        drawPanel = new DrawPanel();

        frame.getContentPane().add(BorderLayout.CENTER, drawPanel);

        frame.setResizable(true);
        frame.setLocationByPlatform(true);

        frame.setVisible(true);

    }

    boolean setupComplete = false;
    //spaceship stiff
    boolean gameOver = false;
    int score = 0;
    int[] ship = {240,440};
    public int speed = 3;
    int dirForAnimation = 0;

    //button press stuff
    public boolean UpButton = false;
    public boolean DownButton = false;
    public boolean RightButton = false;
    public boolean LeftButton = false;
    public boolean SpaceButton = false;
    public boolean RButton = false;

    //rockets
    int numberOfRockets = 6;
    int[][] rockets = new int[numberOfRockets][2];
    int nextRocket = 0;
    int rocketSpeed = 4;
    int timeBetweenShots = 0;
    int rocketDelay = 40;
    //alies stuff
    int numberOfAliens = 15;
    int[][] aliens = new int[numberOfAliens][2];
    boolean[] alienAlive = new boolean[numberOfAliens]; 
    int aliensDead = 0;
    int[] alienSpeed = new int[2];
    int timeCounter = 0;

    //background
    int level = 0;
    int numberOfStars = 100;
    int[][] stars = new int[numberOfStars][3];

    class DrawPanel extends JPanel {
        private static final long serialVersionUID = 1L;     

        public DrawPanel() {
            KeyListener listener = new KeyListener() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                    }

                    @Override
                    public void keyPressed(KeyEvent e) {
                        //System.out.println("keyPressed=" + KeyEvent.getKeyText(e.getKeyCode()));
                        int key = e.getKeyCode();

                        if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W ) {
                            UpButton = true;
                            DownButton = false;
                        } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                            UpButton = false;
                            DownButton = true;
                        } else if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
                            RightButton = true;
                            LeftButton = false;
                        } else if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
                            RightButton = false;
                            LeftButton = true;
                        }
                        if (key == KeyEvent.VK_SPACE) {
                            SpaceButton = true;
                        }
                        if (key == KeyEvent.VK_R) {
                            RButton = true;
                        }
                    }

                    @Override
                    public void keyReleased(KeyEvent e) {
                        int key = e.getKeyCode();

                        if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
                            UpButton = false;
                        } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                            DownButton = false;
                        } else if (key == KeyEvent.VK_RIGHT|| key == KeyEvent.VK_D) {
                            RightButton = false;
                        } else if (key == KeyEvent.VK_LEFT|| key == KeyEvent.VK_A) {
                            LeftButton = false;
                        }
                        if (key == KeyEvent.VK_SPACE) {
                            SpaceButton = false;
                        }
                        if (key == KeyEvent.VK_R) {
                            RButton = false;
                        }
                    }
                };
            addKeyListener(listener);
            setFocusable(true);
        }

        public void paintComponent(Graphics g) {
            //redrawing the scene
            try {
                Thread.sleep(10);
            } catch (Exception e) {
                e.printStackTrace();
            }
            frame.repaint();

            //Check to see if game should restart
            if(aliensDead == 15)
            {
                setupComplete = false;
                aliensDead = 0;
            }

            //This will only run once

            if(!setupComplete)
            {
                for(int alienNum = 0;alienNum<aliens.length;alienNum++)
                {
                    alienAlive[alienNum] = true;
                    aliens[alienNum][0] = 50+alienNum%5*60;
                    aliens[alienNum][1] = 40+alienNum/5*40;   
                }
                for(int rocketNum = 0;rocketNum<rockets.length;rocketNum++)
                {
                    rockets[rocketNum][0] = -50;
                }
                level++;
                setupComplete = true;
                alienSpeed[0] = 1;
                alienSpeed[1] = 0;
                timeCounter = 0;
                Random random = new Random();

                //calculate star positions and size;
                for(int i = 0; i<numberOfStars ; i++)
                {
                    stars[i][0] = random.nextInt(500);
                    stars[i][1] = random.nextInt(500);
                    stars[i][2] = random.nextInt(2)+2;
                }
            }
            //draw the stars
            g.setColor(Color.WHITE);
            for(int i = 0; i<numberOfStars ; i++)
            {
                g.fillOval(stars[i][0],stars[i][1],stars[i][2],stars[i][2]);
            }

            //This section displays indicators to show when buttons are pushed
            g.setColor(Color.GRAY);
            g.fillRect(40,420,20,20);
            g.fillRect(40,460,20,20);
            g.fillRect(20,440,20,20);
            g.fillRect(60,440,20,20);
            g.fillRect(20,485,60,10);
            g.setColor(Color.YELLOW);
            if(UpButton)
                g.fillRect(40,420,20,20);
            if(DownButton)
                g.fillRect(40,460,20,20);
            if(LeftButton)
                g.fillRect(20,440,20,20);
            if(RightButton)
                g.fillRect(60,440,20,20);
            if(SpaceButton)
            {    
                g.fillRect(20,485,60,10);   
            }
            if(gameOver && RButton)
                {
                    gameOver = false;
                    score = 0;
                    setupComplete = false;
                    ship[0] = 240;
                    level = 0;
                    aliensDead = 0;
                }
            String display1 = "DIRECTIONS:";
            String display2 = "up,down,left,and right = move square";
            String display3 = "space bar = Fire a Rocket";
            g.drawString(display1,250 , 450);
            g.drawString(display2,250 , 470);
            g.drawString(display3,250 , 490);
            String display4 = "SCORE: "+score;
            g.drawString(display4,400 , 20);
            String display5 = "LEVEL: "+level;
            g.drawString(display5,40 , 20);

            //------------------ACTUAL GAME CODE---------------------

            //-------------------------------------the ship controller
            //Changes the position of the square
            if(!gameOver)
            {
                if (UpButton &&  ship[1] > 325) 
                {
                    ship[1] -= speed;
                } 
                else if (DownButton && ship[1] < 480) 
                {
                    ship[1] +=speed;
                }
                dirForAnimation = 0;
                if (RightButton && ship[0] <= 480) 
                {
                    ship[0] += speed;
                    dirForAnimation = 1;
                } 
                else if (LeftButton && ship[0] > 0) 
                {
                    ship[0] -= speed;
                    dirForAnimation = -1;
                }
                if(SpaceButton)
                {
                    g.setColor(Color.CYAN);                
                }
                else
                {
                    g.setColor(Color.WHITE);     
                }

                drawShip1(g,ship[0],ship[1],timeCounter,dirForAnimation);
            }
            //--------------------------------------the rockets controller
            if(!gameOver)
            {
                timeBetweenShots--;
                if(SpaceButton && timeBetweenShots<0)
                {
                    rockets[nextRocket][0] = ship[0];
                    rockets[nextRocket][1] = ship[1];
                    nextRocket = (nextRocket+1)%numberOfRockets;
                    timeBetweenShots = rocketDelay;
                }

                for(int rocketNum = 0;rocketNum<rockets.length;rocketNum++)
                {
                    rockets[rocketNum][1] -= rocketSpeed;
                    g.setColor(Color.RED);
                    g.fillOval(rockets[rocketNum][0]-2,rockets[rocketNum][1]-5,5,10);
                }
            }
            //--------------------------------------aliens controls
            g.setColor(Color.GREEN);
            timeCounter += level;
            //alien movement pattern
            if(timeCounter%400 <= 180)
            {
                alienSpeed[0] = level;
                alienSpeed[1] = 0;
            }
            else if(timeCounter%400 <= 200 || timeCounter%400 > 380)
            {
                alienSpeed[0] = 0;
                alienSpeed[1] = level;
            }
            else
            {
                alienSpeed[0] = -1*level;
                alienSpeed[1] = 0;
            }

            //alien movement and drawing
            for(int alienNum = 0;alienNum<aliens.length;alienNum++)
            {
                aliens[alienNum][0] += alienSpeed[0];
                aliens[alienNum][1] += alienSpeed[1];
                if(alienAlive[alienNum])
                {
                    drawAlien1(g,aliens[alienNum][0],aliens[alienNum][1],level);
                }
            }
            //------------------------Rocket-alien collisions
            for(int r = 0; r<numberOfRockets;r++)
            {
                for(int a = 0; a <aliens.length; a++)
                {
                    if(distance(rockets[r],aliens[a])<20 && alienAlive[a])
                    {
                        alienAlive[a] = false;
                        rockets[r][0]=-100;
                        aliensDead++;
                        score++;
                    }
                }
            }  
            //-------------------------Ship-Alien collision
            for(int a = 0; a <aliens.length; a++)
            {
                if(distance(ship,aliens[a])<20 && alienAlive[a] ||aliens[a][1]>500)
                {
                    gameOver = true;
                    ship[0]= -200;
                }
            }
            if(gameOver)
            {
                g.setColor(Color.MAGENTA);
                g.setFont(new Font("TimesRoman", Font.PLAIN, 80));
                g.drawString("GAMEOVER", 40, 200);
                g.setFont(new Font("TimesRoman", Font.PLAIN, 40));
                g.drawString("Press R to Restart", 140, 300);

            }
        }
    }
    public static int distance(int[] a, int[] b)
    {
        int distance;
        distance = (int)Math.sqrt(Math.pow((double)a[0]-b[0],2)+Math.pow((double)a[1]-b[1],2));
        return distance;

    }

    public static void drawShip1(Graphics g, int x, int y,int time,int dir)
    {
        g.setColor(Color.GRAY);
        Polygon body=new Polygon();
        body.addPoint(x-2,y-10);
        body.addPoint(x+2,y-10);    
        body.addPoint(x+4,y); 
        if(dir != 1)
        {
            body.addPoint(x+10,y+4);    
            body.addPoint(x+10,y+9); 
        }
        else
        {
            body.addPoint(x+7,y+5);    
            body.addPoint(x+7,y+10); 
        }
        body.addPoint(x+2,y+2);

        body.addPoint(x-2,y+2);
        if(dir != -1 )
        {
        body.addPoint(x-10,y+10);    
        body.addPoint(x-10,y+5);    
        }
        else
        {
            body.addPoint(x-7,y+6);    
            body.addPoint(x-7,y+11); 
        }
        body.addPoint(x-4,y);    
        g.fillPolygon(body); 
        //side canisters
        g.setColor(Color.RED);
        if(dir !=1)
        {
        g.fillRect(x-4,y-6,3,8);
        }
        else
        {
        g.fillRect(x-6,y-6,3,8);
        }
        if(dir !=1)
        {
        g.fillRect(x+3,y-6,3,8);
        }
        else
        {
        g.fillRect(x+1,y-6,3,8);
        }

        g.setColor(Color.YELLOW);
        
        g.drawOval(x-2,y+4,4,6+time%5);
    }

    public static void drawAlien1(Graphics g, int x, int y,int level)
    {
        if(level==1)
            g.setColor(Color.CYAN);
        else if(level==2)
            g.setColor(Color.GREEN);
        else if(level==3)
            g.setColor(Color.RED);
        else if(level==4)
            g.setColor(Color.BLUE);
        else if(level==5)
            g.setColor(Color.WHITE);
        else
            g.setColor(Color.BLACK);
        Polygon body=new Polygon();
        body.addPoint(x,y);       
        body.addPoint(x+5,y+3); 
        body.addPoint(x+5,y+10); 
        body.addPoint(x+10,y+10); 
        body.addPoint(x+10,y-2);
        body.addPoint(x,y-5); 
        body.addPoint(x-10,y-2); 
        body.addPoint(x-10,y+10); 
        body.addPoint(x-5,y+10);
        body.addPoint(x-5,y+3); 
        g.fillPolygon(body); 
        
        g.setColor(Color.BLUE);
        if(level>6)
            g.setColor(Color.BLACK);
        g.fillOval(x-3,y-10,6,15);
        g.setColor(Color.MAGENTA);
        if(level>7)
            g.setColor(Color.BLACK);
        g.drawOval(x-3,y-10,6,15);

    
    }

}
