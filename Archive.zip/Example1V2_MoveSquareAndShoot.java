import java.awt.*;
import java.lang.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent; 
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;
class Draw {
    Graphics g;
    Draw(Graphics g) {
        this.g = g;
    };
}
public class Example1V2_MoveSquareAndShoot {

    JFrame frame;
    DrawPanel drawPanel;

    public static void main(String... args) {
        new Example1V2_MoveSquareAndShoot().go();
    }

    private void go() {
        frame = new JFrame("Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(515, 539));
        frame.setBackground(Color.BLACK);
        frame.pack();
        drawPanel = new DrawPanel();

        frame.getContentPane().add(BorderLayout.CENTER, drawPanel);

        frame.setResizable(true);
        frame.setLocationByPlatform(true);

        frame.setVisible(true);
        
    }
    
    //Global Variables go here
    //Your global variables go here
    int[] playerPos = {250,250};
    int[] playerSpeed = {2,2};
    
    int[][] bulletPos = {   {-50,-50},
                            {-50,-50},
                            {-50,-50}};
    int[][] bulletVel = {   {0,0},
                            {0,0},
                            {0,0}};
    double bulletSpeed = 5;
    int currentBullet = 0;
    int bulletDelay = 50;
    int currentBulletDelay = 0;
    //booleans for user input
    public boolean UpButton = false;
    public boolean DownButton = false;
    public boolean RightButton = false;
    public boolean LeftButton = false;
    boolean SpaceButton = false;
    boolean mouseClicked = false;
    public int[] mouse = {0,0};
    

    

    class DrawPanel extends JPanel {
        private static final long serialVersionUID = 1L;     

        public DrawPanel() {
            KeyListener listener = new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {
                }

                @Override
                public void keyPressed(KeyEvent e) {
                    //System.out.println("keyPressed=" + KeyEvent.getKeyText(e.getKeyCode()));
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W ) {
                        UpButton = true;
                        DownButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        UpButton = false;
                        DownButton = true;
                    }
                    if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
                        RightButton = true;
                        LeftButton = false;
                    } else if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
                        RightButton = false;
                        LeftButton = true;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = true;
                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
                        UpButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        DownButton = false;
                    }
                    if (key == KeyEvent.VK_RIGHT|| key == KeyEvent.VK_D) {
                        RightButton = false;
                    } else if (key == KeyEvent.VK_LEFT|| key == KeyEvent.VK_A) {
                        LeftButton = false;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = false;
                    }
                }
            };
            addKeyListener(listener);
            setFocusable(true);
            
            
            MouseListener mListener = new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    mouseClicked = true;
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                     mouseClicked = false;
                }
                
                @Override
                public void mouseEntered(MouseEvent e) {
                     
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                     
                }
 
            };
            addMouseListener(mListener);
            setFocusable(true);
        }
        
        
        
        public void paintComponent(Graphics g) {
            //This code redraw the scene.  Don't change this
            try {
                Thread.sleep(10);
            } catch (Exception e) {
                e.printStackTrace();
            }
            frame.repaint();
            //This code finds the mouse location
            Point p = MouseInfo.getPointerInfo().getLocation();
            SwingUtilities.convertPointFromScreen(p, frame);
            mouse[0] = p.x;
            mouse[1] = p.y-30;
            
            //Your code goes here
            //Player Movement
            if (UpButton &&  playerPos[1] > 10) 
            {
                playerPos[1] -= playerSpeed[1];
            } 
            else if (DownButton && playerPos[1] < 490) 
            {
                playerPos[1] +=playerSpeed[1];
            }
            
            if (RightButton && playerPos[0] <= 490) 
            {
                playerPos[0] += playerSpeed[0];
            } 
            else if (LeftButton && playerPos[0] > 10) 
            {
                playerPos[0] -= playerSpeed[0];
            }
            
            //draw player
            g.setColor(Color.WHITE);     
            g.fillRect(playerPos[0]-10, playerPos[1]-10, 20, 20);
            
            
            //draw and move bullets
            currentBulletDelay++;
            for(int i =0;i<bulletPos.length;i++)
            {
                //If the bullet leaves the screen, reset position and velocity
                
                if(bulletPos[i][0]<0 || bulletPos[i][0]>500 ||
                    bulletPos[i][1]<0 || bulletPos[i][1]>500)
                {
                    bulletPos[i][0]=100*i;
                    bulletPos[i][1]=20;
                    bulletVel[i][0]=0;
                    bulletVel[i][1]=0;
                    
                    }
                
            }
            if(mouseClicked && currentBulletDelay>bulletDelay)
            {
                bulletPos[currentBullet][0] = playerPos[0];
                bulletPos[currentBullet][1] = playerPos[1];
                double[] mouseDirection = {mouse[0]-playerPos[0],mouse[1]-playerPos[1]};
                double angle = Math.atan(mouseDirection[1]/mouseDirection[0]);
                if(mouse[0]<playerPos[0])
                {
                    angle += Math.PI;
                }
                
                bulletVel[currentBullet][0]=(int)(bulletSpeed*Math.cos(angle));
                bulletVel[currentBullet][1]=(int)(bulletSpeed*Math.sin(angle));
                
                currentBullet = (currentBullet+1)%3;
                currentBulletDelay = 0;
            }
            for(int i =0;i<bulletPos.length;i++)
            {    
            bulletPos[i][0]+= bulletVel[i][0];
            bulletPos[i][1]+= bulletVel[i][1];
            g.setColor(Color.RED);
            g.fillOval(bulletPos[i][0]-5,bulletPos[i][1]-5,10,10);
        }
            
            //This section displays indicators to show when buttons are pushed
            HUD(g,mouse,UpButton,DownButton,RightButton,LeftButton,mouseClicked);
            
        }
    }

    public void HUD(Graphics g, int[] mouse, boolean UpButton,boolean DownButton,boolean RightButton,
                            boolean LeftButton,boolean mouseClicked)
    {
        g.setColor(Color.GRAY);
            g.fillRect(40,420,20,20);
            g.fillRect(40,460,20,20);
            g.fillRect(20,440,20,20);
            g.fillRect(60,440,20,20);
            g.fillRect(20,485,60,10);
            g.fillOval(100,480,15,15);
            g.setColor(Color.YELLOW);
            if(UpButton)
                g.fillRect(40,420,20,20);
            if(DownButton)
                g.fillRect(40,460,20,20);
            if(LeftButton)
                g.fillRect(20,440,20,20);
            if(RightButton)
                g.fillRect(60,440,20,20);
            if(SpaceButton)
                g.fillRect(20,485,60,10);
            if(mouseClicked)
                g.fillOval(100,480,15,15);
            String display1 = "DIRECTIONS:";
            String display2 = "up,down,left,and right = move square";
            String display3 = "space bar = change color of square";
            String display4 = "X:" + mouse[0] + " Y:" + mouse[1];
            g.drawString(display1,250 , 450);
            g.drawString(display2,250 , 470);
            g.drawString(display3,250 , 490);
            g.drawString(display4,120 , 495);    
    }
}
