import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent; 
//import java.awt.event.KeyEvent.*;
class Draw {
    Graphics g;
    Draw(Graphics g) {
        this.g = g;
    };
}
public class Example3_Driving {

    JFrame frame;
    DrawPanel drawPanel;

    public static void main(String... args) {
        new Example3_Driving().go();
    }

    private void go() {
        frame = new JFrame("Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(515, 539));
        frame.setBackground(Color.BLACK);
        frame.pack();
        drawPanel = new DrawPanel();

        frame.getContentPane().add(BorderLayout.CENTER, drawPanel);

        frame.setResizable(true);
        frame.setLocationByPlatform(true);

        frame.setVisible(true);
        
    }
    
    //Global Variables go here
    public int playerY = 250;
    public int playerX = 250;
    public int playerSpeedX = 0;
    public int playerSpeedY = 3;
    
    //other cars
    int[][] cars = {{150,400,2,0,1},
                    {300,400,2,0,1},
                    {300,200,-2,0,4}};
    
    
    
    
    //booleans for button detection.
    //oldVersions of buttons makes it so it only registers when you initially push the button
    
    public boolean UpButton = false;
    public boolean DownButton = false;
    public boolean RightButton = false;
    public boolean oldRightButton = false;
    public boolean LeftButton = false;    
    public boolean oldLeftButton = false;
    public boolean SpaceButton = false;
    
    

    

    class DrawPanel extends JPanel {
        private static final long serialVersionUID = 1L;     

        public DrawPanel() {
            KeyListener listener = new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {
                }

                @Override
                public void keyPressed(KeyEvent e) {
                    //System.out.println("keyPressed=" + KeyEvent.getKeyText(e.getKeyCode()));
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W ) {
                        UpButton = true;
                        DownButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        UpButton = false;
                        DownButton = true;
                    }
                    if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
                        RightButton = true;
                        LeftButton = false;
                    } else if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
                        RightButton = false;
                        LeftButton = true;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = true;
                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
                        UpButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        DownButton = false;
                    }
                    if (key == KeyEvent.VK_RIGHT|| key == KeyEvent.VK_D) {
                        RightButton = false;
                    } else if (key == KeyEvent.VK_LEFT|| key == KeyEvent.VK_A) {
                        LeftButton = false;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = false;
                    }
                }
            };
            addKeyListener(listener);
            setFocusable(true);
        }

        public void paintComponent(Graphics g) {
            //This code redraw the scene.  Don't change this
            try {
                Thread.sleep(10);
            } catch (Exception e) {
                e.printStackTrace();
            }
            frame.repaint();
            //Your code goes here
            if(RightButton && !oldRightButton)
            {
                if(playerSpeedX<0 && playerSpeedY<=0) 
                {
                    playerSpeedX++;
                    playerSpeedY--;
                }
                else if(playerSpeedX>=0 && playerSpeedY<0) 
                {
                    playerSpeedX++;
                    playerSpeedY++;
                }
                else if(playerSpeedX>0 && playerSpeedY>=0) 
                {
                    playerSpeedX--;
                    playerSpeedY++;
                }
                else
                {
                    playerSpeedX--;
                    playerSpeedY--;
                }
                
            }
            if(LeftButton && !oldLeftButton)
            {
                if(playerSpeedX<=0 && playerSpeedY<0) 
                {
                    playerSpeedX--;
                    playerSpeedY++;
                }
                else if(playerSpeedX>0 && playerSpeedY<=0) 
                {
                    playerSpeedX--;
                    playerSpeedY--;
                }
                else if(playerSpeedX>=0 && playerSpeedY>0) 
                {
                    playerSpeedX++;
                    playerSpeedY--;
                }
                else
                {
                    playerSpeedX++;
                    playerSpeedY++;
                }
                
            }
            oldLeftButton = LeftButton;
            oldRightButton = RightButton;
            
            if(UpButton)
            {
                playerX += playerSpeedX;
                playerY += playerSpeedY;
            } else if(DownButton)
            {
                playerX -= playerSpeedX;
                playerY -= playerSpeedY;
            }
            
            
            
            drawPlayer(g,playerX,playerY,playerSpeedX,playerSpeedY);
            //CAR STUFF
            for(int i = 0;i<cars.length;i++)
            {
                if(cars[i][4] == 1 && cars[i][0]>350)
                {
                    cars[i][4] = 2;
                    cars[i][2] = 1;
                    cars[i][3] = -1;
                }
                else if(cars[i][4] == 2 && cars[i][0]>450)
                {
                    cars[i][4] = 3;
                    cars[i][2] = -1;
                    cars[i][3] = -1;
                }
                else if(cars[i][4] == 3 && cars[i][0]<350)
                {
                    cars[i][4] = 4;
                    cars[i][2] = -2;
                    cars[i][3] = 0;
                }
                else if(cars[i][4] == 4 && cars[i][0]<150)
                {
                    cars[i][4] = 5;
                    cars[i][2] = -1;
                    cars[i][3] = 1;
                }
                else if(cars[i][4] == 5 && cars[i][0]<50)
                {
                    cars[i][4] = 6;
                    cars[i][2] = 1;
                    cars[i][3] = 1;
                }
                else if(cars[i][4] == 6 && cars[i][0]>150)
                {
                    cars[i][4] = 1;
                    cars[i][2] = 2;
                    cars[i][3] = 0;
                }
                
                cars[i][0] += cars[i][2];
                cars[i][1] += cars[i][3];
            
                g.setColor(Color.WHITE);
                g.fillOval(cars[i][0]-10,cars[i][1]-10,20,20);
            
            
            
            
            }
            
            
            
            //This section displays indicators to show when buttons are pushed
            g.setColor(Color.GRAY);
            g.fillRect(40,420,20,20);
            g.fillRect(40,460,20,20);
            g.fillRect(20,440,20,20);
            g.fillRect(60,440,20,20);
            g.fillRect(20,485,60,10);
            g.setColor(Color.YELLOW);
            if(UpButton)
                g.fillRect(40,420,20,20);
            if(DownButton)
                g.fillRect(40,460,20,20);
            if(LeftButton)
                g.fillRect(20,440,20,20);
            if(RightButton)
                g.fillRect(60,440,20,20);
            if(SpaceButton)
                g.fillRect(20,485,60,10);
                
            String display1 = "DIRECTIONS:";
            String display2 = "up,down,left,and right = move square";
            String display3 = "space bar = change color of square";
            String display5 = "speedX: "+ playerSpeedX;
            String display6 = "speedY: "+ playerSpeedY;
            g.drawString(display1,250 , 450);
            g.drawString(display2,250 , 470);
            g.drawString(display3,250 , 490);
            
            g.drawString(display5,250 , 50);
            g.drawString(display6,250 , 80);
            
        }
    }
    
    public static void drawPlayer(Graphics g,int x,int y,int spX,int spY)
    {
        g.setColor(Color.WHITE);
        g.fillOval(x-10,y-10,20,20);
        g.setColor(Color.CYAN);
        g.fillOval(x-5+3*spX,y-5+3*spY,10,10);
    }
    
    
}

