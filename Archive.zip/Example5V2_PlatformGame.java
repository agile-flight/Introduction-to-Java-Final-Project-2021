import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent; 
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;
class Draw {
    Graphics g;
    Draw(Graphics g) {
        this.g = g;
    };
}
public class Example5V2_PlatformGame {

    JFrame frame;
    DrawPanel drawPanel;

    public static void main(String... args) {
        new Example5V2_PlatformGame().go();
    }

    private void go() {
        frame = new JFrame("Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(515, 539));
        frame.setBackground(Color.BLACK);
        frame.pack();
        drawPanel = new DrawPanel();

        frame.getContentPane().add(BorderLayout.CENTER, drawPanel);

        frame.setResizable(true);
        frame.setLocationByPlatform(true);

        frame.setVisible(true);
        
    }
    
    //Global Variables go here
    //Your global variables go here
    int[] player = {180,400};
    int[] oldPlayer = {180,400};
    double[] speed = {0,0};
    double gravity = .3;
    double jumpVelocity = -8 ;
    boolean isGrounded = true;
    int t = 0;
    
    //platforms
    int[][] platforms = {{0,410,500,100},
                         {200,300,100,5},
                         {100,200,50,5}};
    
    //booleans for user input
    public boolean UpButton = false;
    public boolean DownButton = false;
    public boolean RightButton = false;
    public boolean LeftButton = false;
    boolean SpaceButton = false;
    boolean mouseClicked = false;
    public int[] mouse = {0,0};
    

    

    class DrawPanel extends JPanel {
        private static final long serialVersionUID = 1L;     

        public DrawPanel() {
            KeyListener listener = new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {
                }

                @Override
                public void keyPressed(KeyEvent e) {
                    //System.out.println("keyPressed=" + KeyEvent.getKeyText(e.getKeyCode()));
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W ) {
                        UpButton = true;
                        DownButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        UpButton = false;
                        DownButton = true;
                    }
                    if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
                        RightButton = true;
                        LeftButton = false;
                    } else if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
                        RightButton = false;
                        LeftButton = true;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = true;
                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    int key = e.getKeyCode();
                    
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
                        UpButton = false;
                    } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                        DownButton = false;
                    }
                    if (key == KeyEvent.VK_RIGHT|| key == KeyEvent.VK_D) {
                        RightButton = false;
                    } else if (key == KeyEvent.VK_LEFT|| key == KeyEvent.VK_A) {
                        LeftButton = false;
                    }
                    if (key == KeyEvent.VK_SPACE) {
                        SpaceButton = false;
                    }
                }
            };
            addKeyListener(listener);
            setFocusable(true);
            
            
            MouseListener mListener = new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    mouseClicked = true;
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                     mouseClicked = false;
                }
                
                @Override
                public void mouseEntered(MouseEvent e) {
                     
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                     
                }
 
            };
            addMouseListener(mListener);
            setFocusable(true);
        }
        
        
        
        public void paintComponent(Graphics g) {
            //This code redraw the scene.  Don't change this
            try {
                Thread.sleep(10);
            } catch (Exception e) {
                e.printStackTrace();
            }
            frame.repaint();
            //This code finds the mouse location
            Point p = MouseInfo.getPointerInfo().getLocation();
            SwingUtilities.convertPointFromScreen(p, frame);
            mouse[0] = p.x;
            mouse[1] = p.y-30;
            
            //Your code goes here
            if(RightButton)
            {
                speed[0]++;
            }
            else if(LeftButton)
            {
                speed[0]--;            
            }

            speed[0] *= 0.92;
            
            player[0] += (int)speed[0];
            
            if(Math.abs(speed[0]) < 0.9){
                speed[0] = 0;
            }
            
            //Jump for the player
            if(SpaceButton && isGrounded)
            {
                speed[1] = jumpVelocity;
                isGrounded = false;
            } 
            if(isGrounded)
            {
                speed[1] = 0;
            }
            else
            {
                speed[1] += gravity;
            }
            player[1] += speed[1];
            //draw the player.
            g.setColor(Color.RED);
            g.fillOval(player[0]-10,player[1]-10,20,20);
            
            //drawing platforms
            g.setColor(Color.GRAY);
            for(int i = 0; i<platforms.length;i++)
            {
                g.fillRect(platforms[i][0],platforms[i][1],platforms[i][2],platforms[i][3]);
            }
            
            //platform landing detection
            if(!isGrounded)
                for(int i = 0; i<platforms.length;i++)
                {
                    if(oldPlayer[1]<platforms[i][1] && player[1]>platforms[i][1] && 
                        player[0]>platforms[i][0] && player[0]<platforms[i][0]+platforms[i][2])
                    {
                        player[1] = platforms[i][1]-10;
                        isGrounded = true;
                        t = i;
                    }
                }
            
            if(isGrounded)
                
                if(player[0] < platforms[t][0]|| player[0] > (platforms[t][0] + platforms[t][3]))
                {
                    isGrounded = false;
                }
                    
            //End of loop clean up and storage
            oldPlayer[0] = player[0];
            oldPlayer[1] = player[1];
            
            
            
            
            
            
            
            
            //This section displays indicators to show when buttons are pushed
            HUD(g,mouse,UpButton,DownButton,RightButton,LeftButton,mouseClicked);
            
        }
    }

    public void HUD(Graphics g, int[] mouse, boolean UpButton,boolean DownButton,boolean RightButton,
                            boolean LeftButton,boolean mouseClicked)
    {
            g.setColor(Color.GRAY);
            g.fillRect(40,420,20,20);
            g.fillRect(40,460,20,20);
            g.fillRect(20,440,20,20);
            g.fillRect(60,440,20,20);
            g.fillRect(20,485,60,10);
            g.fillOval(100,480,15,15);
            g.setColor(Color.YELLOW);
            if(UpButton)
                g.fillRect(40,420,20,20);
            if(DownButton)
                g.fillRect(40,460,20,20);
            if(LeftButton)
                g.fillRect(20,440,20,20);
            if(RightButton)
                g.fillRect(60,440,20,20);
            if(SpaceButton)
                g.fillRect(20,485,60,10);
            if(mouseClicked)
                g.fillOval(100,480,15,15);
            String display1 = "DIRECTIONS:";
            String display2 = "up,down,left,and right = move square";
            String display3 = "space bar = change color of square";
            String display4 = "X:" + mouse[0] + " Y:" + mouse[1];
            
            String display5 = "SpeedX: " + speed[0];
            g.drawString(display1,250 , 450);
            g.drawString(display2,250 , 470);
            g.drawString(display3,250 , 490);
            g.drawString(display4,120 , 495);
            g.drawString(display5,250 , 430);
            drawGrid(g);
    }
    public static void drawGrid(Graphics g)
    {
        g.setColor(Color.WHITE);
        for (int x = 0; x<=500; x+= 20)
            g.drawLine(x, 0, x, 500);
        for (int y = 0; y<=500; y+= 20)
            g.drawLine(0, y, 500, y); 
        g.setColor(new Color(100,100,100));
        for (int x = 0; x<=500; x+= 100)
            g.drawLine(x, 0, x, 500);
        for (int y = 0; y<=500; y+= 100)
            g.drawLine(0, y, 500, y); 
    
    }
}
